import express from "express";
//importação do arquivo de rotas

const app = express();



export default app;