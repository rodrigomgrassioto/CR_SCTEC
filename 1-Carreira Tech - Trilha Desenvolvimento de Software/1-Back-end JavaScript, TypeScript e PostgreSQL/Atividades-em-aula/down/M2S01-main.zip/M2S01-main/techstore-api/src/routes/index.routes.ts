import {Router, Request, Response} from "express";

const router = Router();

router.get("/", (req: Request, res: Response) => {
    res.status(200).json({
        message: "API TechStore funcionando!"
    })
})

router.get("/sobre", (req: Request, res: Response) => {
    res.status(200).json({
        empresa: "TechStore",
        versao: "1.0.0",
        tecnologia: "Node.js, Express e TypeScript"
    })
})

router.get("/produtos", (req: Request, res: Response) => {
    const produtos = [
        {
            id: 1,
            nome: "Notebook Gamer",
            preco: 5000.00
        },
        {
            id: 2,
            nome: "Teclado Gamer",
            preco: 499.00
        },
        {
            id: 3,
            nome: "Mouse Gamer",
            preco: 200.00
        }
    ]

    res.status(200).json(produtos)
})